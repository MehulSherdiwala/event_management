<?php
require_once 'model/autoload.php';
if (!isset($_SESSION['user_id'])){
    header("Location: index.php");
}
$book = new Book();

$order = $book->getOrder($_SESSION['user_id']);


?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from design.dev.drcsystems.ooo:8084/themeforest/event_planning/account_booking.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Sep 2020 19:22:50 GMT -->
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>Event Planning</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="assets/images/Favicon.ico">
    
    <!-- CSS Stylesheet -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="assets/css/styles.css" rel="stylesheet" /><!-- font css -->
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
    <link href="assets/css/docs.css" rel="stylesheet"><!--  template structure css -->
    
    <!-- Used Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Domine:400,700%7COpen+Sans:300,300i,400,400i,600,600i,700,700i%7CRoboto:400,500" rel="stylesheet"> 
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <style>
        .vendor__rating-group ,
        .rating-group {
            display: inline-flex;
        }
        .vendor__rating__icon ,
        .rating__icon {
            pointer-events: none;
        }

        .vendor__rating__input ,
        .rating__input {
            position: absolute !important;
            left: -9999px !important;
        }

        .vendor__rating__input--none ,
        .rating__input--none {
            display: none
        }

        .vendor__rating__label ,
        .rating__label {
            cursor: pointer;
            padding: 0 0.1em;
            font-size: 2rem;
        }

        .vendor__rating__icon--star ,
        .rating__icon--star {
            color: orange;
        }

        .vendor__rating__input:checked ~ .vendor__rating__label .vendor__rating__icon--star ,
        .rating__input:checked ~ .rating__label .rating__icon--star {
            color: #ddd;
        }

        .vendor__rating-group:hover .vendor__rating__label .vendor__rating__icon--star ,
        .rating-group:hover .rating__label .rating__icon--star {
            color: orange;
        }

        .vendor__rating__input:hover ~ .vendor__rating__label .vendor__rating__icon--star ,
        .rating__input:hover ~ .rating__label .rating__icon--star {
            color: #ddd;
        }
    </style>
</head>

<body class="inner-page">
    <div class="page">
        <?php
        include 'header.php';
        ?>
        <div class="dashboard-banner">
            <div class="container">
                <h2>My Dashboard</h2>
                <div class="breadcrumb">
                    <ul>
                        <li><a href="#">Home</a>/</li>
                        <li class="active"><a href="#">My Account</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container">
                <div class="my-account">
                    <div class="account-tab">
                        <ul>
                            <li><a href="profile.php" id="profile">Profile</a></li>
                            <li class="active"><a href="javascript:void(0);" id="order">Order</a></li>
                            <li><a href="chat.php">Chat</a></li>
                        </ul>
                    </div>
                    <div class="tab-content order-con open">
                        <table class="table table-bordered">
                            <tr>
                                <th>Booking ID</th>
                                <th>Event Name</th>
                                <th class="detail">Event Details</th>
                                <th>Event Date</th>
                                <th>No. of Services</th>
                                <th>Total Amount</th>
                                <th>Venue</th>
                                <th>Location</th>
                                <th></th>
                            </tr>
                                <?php
								foreach ($order as $item)
								{
                                    ?>
                                        <tr>
                                            <td><?= $item['event_id'] ?></td>
                                            <td><?= $item['event_type_name'] ?></td>
                                            <td><?= $item['event_name'] ?></td>
                                            <td><?= date('d M Y', strtotime($item['event_date'])) ?></td>
                                            <td><?= $item['serviceCount'] ?></td>
                                            <td><?= $item['totalAmount'] ?></td>
                                            <td><?= $item['venue'] ?></td>
                                            <td><?= $item['loc'] ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm services" data-eid="<?= $item['event_id']?>" data-toggle="modal" data-target="#view_services"><span class="fa fa-eye"></span></button></td>
                                        </tr>
                                    <?php
                                }
                                ?>
<!--                                <td><span class="small-heading">Booking ID</span>258452112500</td>
                                <td class="detail">
                                    <span class="small-heading">Booking Details</span>
                                    <div class="detailTd">
                                        <label>Hiraba Farm</label>
                                        <p>Behind Shalby Hospital, Garden Road, Prahlad Nagar , Ahmedabad-380015</p>
                                        <a href="#">Phone : +91-79-12345678</a>
                                    </div>
                                </td>
                                <td><span class="small-heading">Booking Date</span>25<sup>th</sup> Aug 2015</td>
                                <td><span class="small-heading">Event Date</span>15<sup>th</sup> Dec 2015</td>
                                <td><span class="small-heading">Paid Amount</span>$ 42,710</td>
                                <td><span class="small-heading">Meals</span>Evening</td>
                                <td><span class="small-heading">No. of Guests</span>1000</td>-->
                        </table>
                    </div>
                </div>
                <div class="functionality-view">
                    <div class="row">
                        <div class="col-sm-6 col-md-3">
                            <div class="functionality-box">
                                <div class="iconBox"><div class="icon icon-lead-management"></div></div>
                                <h3>Lead Management</h3>
                                <p>Increase occupancy, automate the lead management process, grow your  customer relationships, match sales-ready leads to the appropriate sales people.</p>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="functionality-box">
                                <div class="iconBox"><div class="icon icon-sales"></div></div>
                                <h3>Sales</h3>
                                <p>Track sales opportunities, manage the sales process and generate proposals. Built-in process provides an aggregate view of account activity from the past, present and future.</p>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="functionality-box">
                                <div class="iconBox"><div class="icon icon-booking"></div></div>
                                <h3>Booking</h3>
                                <p>Manage calendars , share availability, easily view events color-coded by status, type or location. Book and manage multiple spaces, venues, and sites all from one master calendar.</p>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="functionality-box">
                                <div class="iconBox"><div class="icon icon-operations"></div></div>
                                <h3>Operations</h3>
                                <p>Assign resources and review stock alerts. Create detailed reports, work orders, and generate invoices. Receive alerts on changes as they take place.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
            include 'footer.php';
        ?>
    </div>
    <div class="modal fade " id="view_services" tabindex="-1" role="dialog" >
        <div class="modal-dialog contactvendor-popup modal-lg" role="document">
            <div class="modal-content">
                <div class="close-icon" aria-label="Close" data-dismiss="modal" ><img src="assets/images/close-icon.png" alt=""></div>
                <h1>Event Services</h1>
<!--                <div class="note">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div>-->
                <div class="row" style="padding: 20px">
                    <div id="services"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade " id="ratings" tabindex="-1" role="dialog" >
        <div class="modal-dialog contactvendor-popup modal-lg" role="document">
            <div class="modal-content">
                <div class="close-icon" aria-label="Close" data-dismiss="modal" ><img src="assets/images/close-icon.png" alt=""></div>
                <h1>Event Services</h1>
<!--                <div class="note">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div>-->
                <div class="row" style="padding: 20px">
                    <form action="rate_review_action.php" method="post">
                        <h4><b>Vendor Service Rate & Review</b></h4>
                        <div class="form-group">
                            <label>Rate : : </label>
                            <div id="full-stars-example-two">
                                <div class="rating-group">
                                    <input disabled checked class="rating__input rating__input--none" name="service_rating" id="rating-none" value="0" type="radio">
                                    <label aria-label="1 star" class="rating__label" for="rating-1"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                    <input class="rating__input" name="service_rating" id="rating-1" value="1" type="radio">
                                    <label aria-label="2 stars" class="rating__label" for="rating-2"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                    <input class="rating__input" name="service_rating" id="rating-2" value="2" type="radio">
                                    <label aria-label="3 stars" class="rating__label" for="rating-3"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                    <input class="rating__input" name="service_rating" id="rating-3" value="3" type="radio">
                                    <label aria-label="4 stars" class="rating__label" for="rating-4"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                    <input class="rating__input" name="service_rating" id="rating-4" value="4" type="radio">
                                    <label aria-label="5 stars" class="rating__label" for="rating-5"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                    <input class="rating__input" name="service_rating" id="rating-5" value="5" type="radio">
                                </div>
                                <input type="hidden" name="vendor_service_id" id="vendor_service_id">
                                <input type="hidden" name="vendor_service_rate_id" id="vendor_service_rate_id">
                                <input type="hidden" name="vendor_service_review_id" id="vendor_service_review_id">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Review : : </label>
                            <textarea name="service_review" id="service_review" class="form-control" placeholder="Write Review" style="width: 50%;"></textarea
                        </div>
                        <hr>
                        <h4><b>Vendor Rate & Review</b></h4>
                        <div class="form-group">
                            <label>Rate : : </label>
                            <div id="full-stars-example-two">
                                <div class="vendor__rating-group">
                                    <input disabled checked class="vendor__rating__input vendor__rating__input--none" name="vendor_rating" id="vendor__rating-none" value="0" type="radio">
                                    <label aria-label="1 star" class="vendor__rating__label" for="vendor-rating-1"><i class="vendor__rating__icon vendor__rating__icon--star fa fa-star"></i></label>
                                    <input class="vendor__rating__input" name="vendor_rating" id="vendor-rating-1" value="1" type="radio">
                                    <label aria-label="2 stars" class="vendor__rating__label" for="vendor-rating-2"><i class="vendor__rating__icon vendor__rating__icon--star fa fa-star"></i></label>
                                    <input class="vendor__rating__input" name="vendor_rating" id="vendor-rating-2" value="2" type="radio">
                                    <label aria-label="3 stars" class="vendor__rating__label" for="vendor-rating-3"><i class="vendor__rating__icon vendor__rating__icon--star fa fa-star"></i></label>
                                    <input class="vendor__rating__input" name="vendor_rating" id="vendor-rating-3" value="3" type="radio">
                                    <label aria-label="4 stars" class="vendor__rating__label" for="vendor-rating-4"><i class="vendor__rating__icon vendor__rating__icon--star fa fa-star"></i></label>
                                    <input class="vendor__rating__input" name="vendor_rating" id="vendor-rating-4" value="4" type="radio">
                                    <label aria-label="5 stars" class="vendor__rating__label" for="vendor-rating-5"><i class="vendor__rating__icon vendor__rating__icon--star fa fa-star"></i></label>
                                    <input class="vendor__rating__input" name="vendor_rating" id="vendor-rating-5" value="5" type="radio">
                                </div>
                                <input type="hidden" name="vendor_id" id="vendor_id">
                                <input type="hidden" name="vendor_rate_id" id="vendor_rate_id">
                                <input type="hidden" name="vendor_review_id" id="vendor_review_id">

                            </div>
                        </div>
                        <div class="form-group">
                            <label>Review : : </label>
                            <textarea name="vendor_review" id="vendor_review" class="form-control" placeholder="Write Review" style="width: 50%;"></textarea
                        </div>
                        <br>
                        <button type="submit" class="btn btn-block" style="width: 15%">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Bootstrap core JavaScript
        ================================================== --> 
    <!-- Placed at the end of the document so the pages load faster --> 
    <script type="text/javascript" src="assets/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.selectbox-0.2.js"></script>
    <script type="text/javascript" src="assets/js/coustem.js"></script>
    <script type="text/javascript" src="assets/js/placeholder.js"></script>

    <script>
        $("#ratings").on('show.bs.modal', function (){
            $("#view_services").modal('hide');
        })
        $(".services").on('click', function (){
            let id = $(this).data('eid');
            let status = [
                "Waiting for Approval",
                "Rejected",
                "Waiting for payment",
                "Finalized",
                "Completed",
            ];

            $.ajax({
                url: '<?= base_url?>model/services.php?ajax=true&event_service=true&event_id='+id,
                success:function (res){
                    let obj = JSON.parse(res);
                    let html = '';

                    for (const key in obj) {
                        html += '<table class="table table-bordered table-striped">' +
                            '    <tr>' +
                            '        <td width="190px">Vendor Service Id</td>' +
                            '        <td>' + obj[key].vendor_service_id + '</td>' +
                            '        <td width="130px">Service Name</td>' +
                            '        <td>' + obj[key].service_name + '</td>' +
                            '    </tr>' +
                            '    <tr>' +
                            '        <td>Vendor Service Name</td>' +
                            '        <td>' + obj[key].vendor_service_name + '</td>' +
                            '        <td>Amount</td>' +
                            '        <td>' + obj[key].amount + '</td>' +
                            '    </tr>' +
                            '    <tr>' +
                            '        <td>Description</td>' +
                            '        <td>' + obj[key].description + '</td>' +
                            '        <td>Commission</td>' +
                            '        <td>' + obj[key].commission + '</td>' +
                            '    </tr>' +
                            '    <tr>' +
                            '        <td>Payment Mode</td>' +
                            '        <td>' + ((obj[key].payment_mode==null)? "Not Yet Done" :obj[key].payment_mode ) + '</td>' +
                            '        <td>Deposit</td>' +
                            '        <td>' + obj[key].deposit + '</td>' +
                            '    </tr>' +
                            '    <tr>' +
                            '        <td>Images</td>' +
                            '        <td><img src="../images/' + obj[key].image + '" alt="" class="img-responsive img-100"></td>' +
                            '        <td>Status</td>' +
                            '        <td>' + status[obj[key].status] + '</td>' +
                            '    </tr>' +
                            '</table>';
                        if (obj[key].status > 1 && obj[key].amount > obj[key].deposit){
                            html += '<div class="text-right"><a href="payment.php?book_id=' + obj[key].book_id + '" class="btn btn-sm" style="margin-bottom: 15px;">Pay Now</a></div>'
                        }
                        if (obj[key].status > 1 && obj[key].amount == obj[key].deposit){
                            html += '<div class="text-left"><button type="button" data-sid="' + obj[key].vendor_service_id + '" data-vid="' + obj[key].vendor_id + '" data-toggle="modal" data-target="#ratings" class="btn btn-sm give_rate" style="margin-bottom: 15px;">Rate & Review</button></div>'
                        }
                    }
                    $("#services").html(html);
                    $(".give_rate").on('click', function (){
                        let sid = $(this).data('sid');
                        let vid = $(this).data('vid');
                        fetchRateReview(sid, vid);
                    });
                }
            });
        });

        async function fetchRateReview(sid, vid){
            const res = await fetch('model/services.php?ajax=true&vendor_service_id=' + sid + "&vendor_id=" + vid);
            const data = await res.json();

            $("#vendor_id").val(vid);
            $("#vendor_service_id").val(sid);

            if(data['service'] != null){
                $("#rating-" + data.service.rate).prop('checked' , true);
                $("#service_review").val(data.service.review);
                $("#vendor_service_rate_id").val(data.service.vendor_service_rate_id);
                $("#vendor_service_review_id").val(data.service.vendor_service_review_id);
            }
            if(data['vendor'] != null){
                $("#vendor-rating-" + data.vendor.rate).prop('checked' , true);
                $("#vendor_review").val(data.vendor.review);
                $("#vendor_rate_id").val(data.vendor.vendor_rate_id);
                $("#vendor_review_id").val(data.vendor.vendor_review_id);
            }
        }

    </script>
</body>
</html>
