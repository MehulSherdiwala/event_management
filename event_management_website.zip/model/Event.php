<?php
require_once 'autoload.php';
date_default_timezone_set("Asia/kolkata");

class Event extends Database {

	public function __construct()
	{
		$date = date('Y-m-d');
		$sql = "select * from service_book join event e on e.event_id = service_book.event_id where event_date >= '$date' and status = 3";
		$res = $this->connect()->query($sql);
		if ($res->num_rows > 0)
		{
			while ($row = $res->fetch_object())
			{
				$this->update('service_book', ['book_id', $row->book_id], ['status' => 4]);
			}
		}
	}

	public function getEnventType($id = 0){
		if ($id == 0)
		{
			if (gettype($id) == 'string'){
				$sql = "select * from event_type where event_type_name like '%$id%'";
			} else
			{
				$sql = "select * from event_type";
			}

			$res = $this->connect()->query($sql);

			$event = [];
			while ($row = $res->fetch_object())
			{
				$event[] = $row;
			}
		} else {
			$sql = "select * from event_type where event_type_id=".$id;

			$res = $this->connect()->query($sql);

			$row = $res->fetch_object();

			$event = array(
				'event_type_id' => $row->event_type_id,
				'event_type_name' => $row->event_type_name,
				'image' => $row->image,
			);
		}
		return $event;
	}

	public function getUserEvents($id = 0, $type = 'user'){
		if ($id == 0 && $type == 'user')
		{
			$sql = "select * from event inner join event_type et on event.event_type_id = et.event_type_id inner join city c on event.city_id = c.city_id inner join user u on event.user_id = u.user_id";

			$res = $this->connect()->query($sql);

			$event = [];
			while ($row = $res->fetch_object())
			{
				$event[] = array(
					'event_id' => $row->event_id,
					'event_name' => $row->event_name,
					'event_date' => $row->event_date,
					'venue' => $row->venue,
					'event_type_name' => $row->event_type_name,
					'city_name' => $row->city_name,
					'user_name' => $row->user_name,
				);
			}
		} else if($id != 0 && $type == 'vendor')
		{
			$sql = "select 
    					distinct event.event_id, user_name, event_type_name, event_name, city_name, venue, event_date 
							from event 
							    inner join event_type et on event.event_type_id = et.event_type_id 
							    inner join city c on event.city_id = c.city_id 
							    inner join user u on event.user_id = u.user_id 
							    inner join service_book sb on event.event_id = sb.event_id 
							    inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id
							where sb.status > 1 and vendor_id = " . $id;

			$res = $this->connect()->query($sql);
			$event = [];

			while ($row = $res->fetch_object())
			{
				$event[] = array(
					'event_id' => $row->event_id,
					'event_name' => $row->event_name,
					'event_type_name' => $row->event_type_name,
					'user_name' => $row->user_name,
					'city_name' => $row->city_name,
					'venue' => $row->venue,
					'event_date' => $row->event_date,
				);
			}

		} else  {
			$sql = "select *
						from event 
    						inner join event_type et on event.event_type_id = et.event_type_id 
						    inner join city c on event.city_id = c.city_id 
						    inner join user u on event.user_id = u.user_id
						where u.user_id=".$id;

			$res = $this->connect()->query($sql);

			$event = [];
			while ($row = $res->fetch_object())
			{
				$event[] = array(
					'event_id' => $row->event_id,
					'event_name' => $row->event_name,
					'event_date' => $row->event_date,
					'venue' => $row->venue,
					'event_type_name' => $row->event_type_name,
					'city_name' => $row->city_name,
					'user_name' => $row->user_name,
				);
			}

		}
		return $event;
	}

	public function getEventWiseUsers(){
		$sql = "select distinct u.user_id, user_name from event inner join user u on event.user_id = u.user_id";

		$res = $this->connect()->query($sql);

		$event = [];
		while ($row = $res->fetch_object())
		{
			$event[] = array(
				'user_id' => $row->user_id,
				'user_name' => $row->user_name,
			);
		}
		return $event;

	}

	public function getEventWiseVendors(){
		$sql = "select 
    					distinct v.vendor_id, vendor_name 
							from event 
							    inner join service_book sb on event.event_id = sb.event_id 
							    inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id
							    inner join vendor v on vs.vendor_id = v.vendor_id";

		$res = $this->connect()->query($sql);
		$event = [];

		while ($row = $res->fetch_object())
		{
			$event[] = array(
				'vendor_id' => $row->vendor_id,
				'vendor_name' => $row->vendor_name
			);
		}

		return $event;

	}

	public function getEventTypeWise($event_type_id){

		$sql = "select 
    					distinct event.event_id, user_name, event_type_name, event_name, city_name, venue, event_date 
							from event 
							    inner join event_type et on event.event_type_id = et.event_type_id 
							    inner join city c on event.city_id = c.city_id 
							    inner join user u on event.user_id = u.user_id 
							where et.event_type_id = " . $event_type_id;

		$res = $this->connect()->query($sql);
		$event = [];

		while ($row = $res->fetch_object())
		{
			$event[] = array(
				'event_id' => $row->event_id,
				'event_name' => $row->event_name,
				'event_date' => $row->event_date,
				'event_type_name' => $row->event_type_name,
				'city_name' => $row->city_name,
				'venue' => $row->venue,
				'user_name' => $row->user_name,
			);
		}

		return $event;

	}

	public function getLocWiseUserEvents($country, $state, $city){
		$sql = "select *
						from event 
    						inner join event_type et on event.event_type_id = et.event_type_id 
						    inner join city c on event.city_id = c.city_id 
						    inner join user u on event.user_id = u.user_id ";
		if ($city != 0){
			$sql .= " where city_id=".$city;
		} elseif ($state != 0){
			$sql .= " c.state_id=".$state;
		} elseif ($country != 0)
		{
			$sql .= " inner join state s on s.state_id=c.state_id where s.country_id=".$country;
		}
		$res = $this->connect()->query($sql);
		$event = [];

		while ($row = $res->fetch_object())
		{
			$event[] = array(
				'event_id' => $row->event_id,
				'event_name' => $row->event_name,
				'event_date' => $row->event_date,
				'event_type_name' => $row->event_type_name,
				'city_name' => $row->city_name,
				'venue' => $row->venue,
				'user_name' => $row->user_name,
			);
		}

		return $event;
	}

	public function getDateWiseEvents($date, $id=0){
		$sql = "select 
    					distinct event.event_id, user_name, event_type_name, event_name, city_name, venue, event_date 
							from event 
							    inner join event_type et on event.event_type_id = et.event_type_id 
							    inner join city c on event.city_id = c.city_id 
							    inner join user u on event.user_id = u.user_id 
							    inner join service_book sb on event.event_id = sb.event_id 
							    inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id
							where sb.status > 1  and event_date = '" . date('Y-m-d', strtotime($date)) . "'";
		if ($id!= 0)
		{
			$sql .= "and vendor_id = ".$id;
		}
		$res = $this->connect()->query($sql);
		$event = [];

		while ($row = $res->fetch_object())
		{
			$event[] = array(
				'event_id' => $row->event_id,
				'event_name' => $row->event_name,
				'event_type_name' => $row->event_type_name,
				'user_name' => $row->user_name,
				'city_name' => $row->city_name,
				'venue' => $row->venue,
				'event_date' => $row->event_date,
			);
		}
		return $event;
	}


	public function getServicesWiseEvents($vendor_service_id, $id){
		$sql = "select 
    					distinct event.event_id, user_name, event_type_name, event_name, city_name, venue, event_date 
							from event 
							    inner join event_type et on event.event_type_id = et.event_type_id 
							    inner join city c on event.city_id = c.city_id 
							    inner join user u on event.user_id = u.user_id 
							    inner join service_book sb on event.event_id = sb.event_id 
							    inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id
							where sb.status > 1 and vendor_id = " . $id . " and sb.vendor_service_id = " . $vendor_service_id;

		$res = $this->connect()->query($sql);
		$event = [];

		while ($row = $res->fetch_object())
		{
			$event[] = array(
				'event_id' => $row->event_id,
				'event_name' => $row->event_name,
				'event_type_name' => $row->event_type_name,
				'user_name' => $row->user_name,
				'city_name' => $row->city_name,
				'venue' => $row->venue,
				'event_date' => $row->event_date,
			);
		}
		return $event;
	}


}

if(isset($_GET['ajax']) && $_GET['ajax'])
{
	$event = new Event();

	if (isset($_GET['event_type_id'])){
		$eventList = $event->getEnventType($_GET['event_type_id']);
		echo json_encode($eventList);
	} else if (isset($_GET['user_wise'])){
		$eventList = $event->getEventWiseUsers();
		echo json_encode($eventList);
	} else if (isset($_GET['vendor_wise'])){
		$eventList = $event->getEventWiseVendors();
		echo json_encode($eventList);
	} else
	{

		$eventList = $event->getEnventType();
		echo json_encode($eventList);
	}
}
