$(function () {
	$('#dp1').datepicker({
		format: 'mm-dd-yyyy'
	});
	$('#dp2').datepicker({
		format: 'mm-dd-yyyy'
	});
	$('#dp3').datepicker({
		format: 'mm-dd-yyyy'
	});

});