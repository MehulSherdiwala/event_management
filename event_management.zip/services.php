<?php
require_once 'model/autoload.php';

$service = new Services();

if (isset($_GET['event_id']))
{
    $event = new Event();
	$e     = $event->getEnventType($_GET['event_id']);

}
$serv = $service->getServicesType(($_GET['search'] ?? ''));

?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from design.dev.drcsystems.ooo:8084/themeforest/event_planning/search-result.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Sep 2020 19:19:20 GMT -->
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->

    <!-- Title -->
    <title>Event Planning</title>

    <!-- favicon icon -->
    <link rel="shortcut icon" href="assets/images/Favicon.ico">

    <!-- CSS Stylesheet -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="assets/css/styles.css" rel="stylesheet" /><!-- font css -->
    <link href="assets/css/jquery.selectbox.css" rel="stylesheet" /><!-- select Box css -->
    <link href="assets/css/datepicker.css" rel="stylesheet" /><!-- Date picker css -->
    <link href="assets/css/docs.css?version=1" rel="stylesheet"><!--  template structure css -->

    <!-- Used Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Domine:400,700%7COpen+Sans:300,300i,400,400i,600,600i,700,700i%7CRoboto:400,500" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
<body class="inner-page">
	<div class="page">

        <?php
            include 'header.php';
        ?>

        <div class="searchFilter-main">
            <section class="searchFormTop">
                <div class="container">
                    <div class="searchCenter">
                        <div class="refineCenter">
                            <span class="icon icon-filter"></span>
                            <span>Refine Results</span>
                        </div>
                        <div class="searchFilter">
                            <form method="get">
                                <div class="input-box">
                                    <div class="icon icon-grid-view"></div>
									<?php
									if (isset($_GET['event_id']))
									{
										echo "<input type='hidden' name='event_id' value='" . $_GET['event_id'] . "' />";
									}
									?>
                                    <input type="text" name="search" placeholder="Search Services" value="<?= ($_GET['search'] ?? '') ?>">

                                </div>
                                <!--                            <div class="input-box searchlocation">-->
                                <!--                                <div class="icon icon-location-1"></div>-->
                                <!--                                <input type="text" placeholder="Germany - Berlin / East">-->
                                <!--                            </div>-->
                                <input type="submit" class="btn">
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <section class="content">
                <div class="breadcrumb">
                    <div class="container">
                        <ul>
                            <li><a href="index.php">Home</a>/</li>
                            <li><a href="event.php"><?= $e['event_type_name'] ?? 'Events' ?></a>/</li>
                            <li><a href="#">Services</a></li>
                        </ul>
                    </div>
                </div>
                <div class="container">
                    <div class="venues-view">
                        <div class="row">
                            <div class="col-md-10 col-lg-10 col-sm-12 col-lg-offset-1">
                                <div class="right-side">
                                    <div class="toolbar">
                                        <div class="finde-count"><?= count($serv)?> Service(s) found.  </div>

                                    </div>
                                    <?php
                                        foreach ($serv as $item)
                                        {

                                    ?>
                                    <div class="venues-slide">
                                        <div class="img"><img src="images/<?= $item->image?>" alt=""></div>
                                        <div class="text">
                                            <h3><?= $item->service_name ?> </h3>
                                            <h4>Providers</h4>
                                            <div class="address">
                                                <?php
                                                $vendorService = $service->getVendorServiceByService($item->service_id);

                                                $i=0;
												foreach($vendorService as $vs)
												{
												    if ($i++ == 4){
												        break;
													}
													echo $vs['org_name'] . " at Rs. " . $vs['amount']  . "<br>";
												}
                                                ?>
                                            </div>

                                            <div class="button">
                                                <a href="vendor_services.php?<?= (isset($_GET['event_id']) ? "event_id=" . $_GET['event_id']. "&" : '' )?>service_id=<?= $item->service_id?>" class="btn">View Vendors</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php
        include 'footer.php';
        ?>
    </div>



    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script type="text/javascript" src="assets/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.js"></script>
    <script type="text/javascript" src="assets/js/jquery.selectbox-0.2.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="assets/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="assets/js/placeholder.js"></script>
    <script type="text/javascript" src="assets/js/coustem.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>

</body>
</html>

