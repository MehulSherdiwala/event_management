<?php
require_once 'autoload.php';


class Vendor extends Database {

	public function login(){
		if (isset($_POST['email'])){
			$email		= $_POST['email'];
			$password	= $this->getEncrypt($_POST['password']);

			$sql 	= "select vendor_id,vendor_name from vendor where email='$email' and password='$password'";
			$result = $this->connect()->query($sql);

			$numRows = $result->num_rows;

			if ($numRows > 0)
			{
				$row = $result->fetch_object();
				$_SESSION['vendor_id'] = $row->vendor_id;
				$_SESSION['vendor_name'] = $row->vendor_name;
				return TRUE;
			}
			return FALSE;
		}
	}

	public function getCount(){
		$sql = "select 
    					user_id
						from  event 
							inner join event_type et on event.event_type_id = et.event_type_id 
							inner join service_book sb on event.event_id = sb.event_id 
							inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id 
					where sb.status > 1 and vs.vendor_id=".$_SESSION['vendor_id'] ." group by user_id";
		$data['users'] = $this->connect()->query($sql)->num_rows;

		$sql = "select sb.event_id
				from event
						 inner join event_type et on event.event_type_id = et.event_type_id
						 inner join service_book sb on event.event_id = sb.event_id
						 inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id
				where sb.status > 1 and vs.vendor_id =".$_SESSION['vendor_id'];
		$data['services'] = $this->connect()->query($sql)->num_rows;

		$sql = "select count(*) as booking from service_book sb inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id where vendor_id=".$_SESSION['vendor_id'];
		$data['booking'] = $this->connect()->query($sql)->fetch_object()->booking;

		$sql = "select sb.event_id
				from event
						 inner join event_type et on event.event_type_id = et.event_type_id
						 inner join service_book sb on event.event_id = sb.event_id
						 inner join vendor_service vs on sb.vendor_service_id = vs.vendor_service_id
				where sb.status > 1 and vs.vendor_id =".$_SESSION['vendor_id']. " group by sb.event_id";
		$data['events'] = $this->connect()->query($sql)->num_rows;


		return $data;
	}


	public function getVendors(): ?array
	{
		$sql = "select * from vendor inner join city c on vendor.city_id = c.city_id";
		$res = $this->connect()->query($sql);
		$numRows = $res->num_rows;

		if ($numRows >0){
			$data = array();
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_id' => $row->vendor_id,
					'vendor_name' => $row->vendor_name,
					'email' => $row->email,
					'address' => $row->address,
					'contact' => $row->contact,
					'status' => $row->status,
					'city_name' => $row->city_name,
					'org_name' => $row->org_name,
				);
			}
			return $data;
		}
	}

	public function getVendorDetails($vendor_id){
		$loc = new Location();
		$sql = "select * from vendor where vendor_id=". $vendor_id;
		$res = $this->connect()->query($sql);
		$numRows = $res->num_rows;
		$data = array();
		if ($numRows > 0)
		{
			$row = $res->fetch_object();
			$data = array(
				'vendor_id' => $row->vendor_id,
				'vendor_name' => $row->vendor_name,
				'email' => $row->email,
				'address' => $row->address,
				'contact' => $row->contact,
				'org_name' => $row->org_name,
				'status' => $row->status,
				'city_id' => $row->city_id,
				'loc' => $loc->getLocation($row->city_id),
			);
		}
		return $data;
	}

	public function getStatusWiseVendors($status){
		$loc = new Location();
		$sql = "select * from vendor where status=".$status;
		$res = $this->connect()->query($sql);
		$numRows = $res->num_rows;
		$data = array();
		if ($numRows > 0)
		{
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_id' => $row->vendor_id,
					'vendor_name' => $row->vendor_name,
					'email' => $row->email,
					'address' => $row->address,
					'contact' => $row->contact,
					'status' => $row->status,
					'city_name' => $loc->getLocation($row->city_id),
					'org_name' => $row->org_name,
				);
			}
		}
		return $data;
	}

	public function getLocWiseVendors($country, $state, $city){
		$loc = new Location();
		$sql = "select * from vendor u";
		if ($city!=0){
			$sql .= " inner join city c on c.city_id=u.city_id where u.city_id=".$city;
		} elseif ($state!=0){
			$sql .= " inner join city c on c.city_id=u.city_id where c.state_id=".$state;
		} elseif ($country!=0){
			$sql .= " inner join city c on c.city_id=u.city_id inner join state s on s.state_id=c.state_id  where s.country_id=".$country;
		}
		$res = $this->connect()->query($sql);
		$numRows = $res->num_rows;
		$data = array();
		if ($numRows > 0)
		{
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_id' => $row->vendor_id,
					'vendor_name' => $row->vendor_name,
					'email' => $row->email,
					'address' => $row->address,
					'contact' => $row->contact,
					'status' => $row->status,
					'city_name' => $loc->getLocation($row->city_id),
					'org_name' => $row->org_name,
				);
			}
		}
		return $data;
	}

	public function getStatus($vendor_id){
		$sql = "select status from vendor where vendor_id=".$vendor_id;
		return $this->connect()->query($sql)->fetch_object()->status;
	}

	public function getVendorRate($vendor_id = 0, $avg = FALSE){
		if ($vendor_id == 0){
			$sql = "select avg(rate) as rate,ur.vendor_id,vendor_name from vendor_rate ur inner join vendor u on ur.vendor_id = u.vendor_id group by ur.vendor_id";
			$res = $this->connect()->query($sql);

			$data = array();
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_id' => $row->vendor_id,
					'vendor_name' => $row->vendor_name,
					'rate' => $row->rate
				);
			}

		} elseif ($vendor_id > 0 && $avg){
			$sql = "select avg(rate) as rate from vendor_rate where vendor_id=". $vendor_id;
			$row = $this->connect()->query($sql)->fetch_object();
			$data = $row->rate;
		} else {
			$sql = "select rate,ur.vendor_rate_id,user_name from vendor_rate ur inner join user u on ur.user_id = u.user_id where ur.vendor_id=".$vendor_id;
			$res = $this->connect()->query($sql);

			$data = array();
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_rate_id' => $row->vendor_rate_id,
					'user_name' => $row->user_name,
					'rate' => $row->rate
				);
			}
		}
			return $data;
	}

	public function getVendorReivew($vendor_id = 0){
		if ($vendor_id == 0){
			$sql = "select review,ur.vendor_id,user_name,v.vendor_name,vendor_review_id from vendor_review ur inner join vendor v on ur.vendor_id = v.vendor_id inner join user u2 on ur.user_id = u2.user_id";
			$res = $this->connect()->query($sql);

			$data = array();
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_review_id' => $row->vendor_review_id,
					'vendor_id' => $row->vendor_id,
					'vendor_name' => $row->vendor_name,
					'user_name' => $row->user_name,
					'review' => $row->review
				);
			}

		}else {
			$sql = "select review,user_name,review_date,vendor_review_id from vendor_review ur inner join user u2 on ur.user_id = u2.user_id where vendor_id=".$vendor_id;
			$res = $this->connect()->query($sql);

			$data = array();
			while ($row = $res->fetch_object())
			{
				$data[] = array(
					'vendor_review_id' => $row->vendor_review_id,
					'review_date' => $row->review_date,
					'user_name' => $row->user_name,
					'review' => $row->review
				);
			}

		}
			return $data;
	}

	public function getAllVendorRateReview($vendor_id){
		$sql = "select user_name,rate,review from vendor v inner join vendor_rate vr on v.vendor_id = vr.vendor_id inner join vendor_review r on v.vendor_id = r.vendor_id inner join user u on r.user_id = u.user_id and vr.user_id=u.user_id where v.vendor_id=".$vendor_id;
		$res = $this->connect()->query($sql);
		$data = [];
		if ($res->num_rows > 0){
			while ($row = $res->fetch_object()){
				$data[] = array(
					'user_name' => $row->user_name,
					'rate' => $row->rate,
					'review' => $row->review,
				);
			}
		}

		return $data;
	}

}

if (isset($_GET['ajax']) ){
	$vendor = new Vendor();

	if (isset($_GET['vendor'])){
		$vendor_id = $_GET['vendor_id'];
		echo json_encode($vendor->getStatus($vendor_id));
	} elseif(isset($_GET['vendor_all_rate_review'])){
		$vendor_id = $_GET['vendor_id'];
		echo json_encode($vendor->getAllVendorRateReview($vendor_id));
	}
}
