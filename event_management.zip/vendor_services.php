<?php
require_once 'model/autoload.php';

if (!isset($_GET['service_id'])){
    header("location:services.php");
}
$service = new Services();
$vendor  = new Vendor();
$loc     = new  Location();

if (isset($_GET['event_id']))
{
	$event = new Event();
	$e = $event->getEnventType($_GET['event_id']);
}
$s = $service->getServicesType($_GET['service_id']);
$serv = $service->getVendorServiceByService($_GET['service_id'],($_GET['search'] ?? ''),FALSE);

?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from design.dev.drcsystems.ooo:8084/themeforest/event_planning/search-result.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Sep 2020 19:19:20 GMT -->
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->

    <!-- Title -->
    <title>Event Planning</title>

    <!-- favicon icon -->
    <link rel="shortcut icon" href="assets/images/Favicon.ico">

    <!-- CSS Stylesheet -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="assets/css/styles.css" rel="stylesheet" /><!-- font css -->
    <link href="assets/css/jquery.selectbox.css" rel="stylesheet" /><!-- select Box css -->
    <link href="assets/css/datepicker.css" rel="stylesheet" /><!-- Date picker css -->
    <link href="assets/fonts/fontawesome/css/all.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/docs.css?version=1" rel="stylesheet"><!--  template structure css -->

    <!-- Used Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Domine:400,700%7COpen+Sans:300,300i,400,400i,600,600i,700,700i%7CRoboto:400,500" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
<body class="inner-page">
	<div class="page">

        <?php
            include 'header.php';
        ?>

        <div class="searchFilter-main">
            <section class="searchFormTop">
                <div class="container">
                    <div class="searchCenter">
                        <div class="refineCenter">
                            <span class="icon icon-filter"></span>
                            <span>Refine Results</span>
                        </div>
                        <div class="searchFilter">
                            <form method="get">
                                <?php
								if (isset($_GET['event_id']))
								{
									echo "<input type='hidden' name='event_id' value='" . $_GET['event_id'] . "' />";
								}
								if (isset($_GET['service_id']))
								{
									echo "<input type='hidden' name='service_id' value='" . $_GET['service_id'] . "' />";
								}
								?>
                                <div class="input-box">
                                    <div class="icon icon-grid-view"></div>
                                    <input type="text" name="search" placeholder="Search Services" value="<?= ($_GET['search'] ?? '') ?>">
                                </div>
                                <!--                            <div class="input-box searchlocation">-->
                                <!--                                <div class="icon icon-location-1"></div>-->
                                <!--                                <input type="text" placeholder="Germany - Berlin / East">-->
                                <!--                            </div>-->
                                <input type="submit" class="btn">
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <section class="content">
                <div class="breadcrumb">
                    <div class="container">
                        <ul>
                            <li><a href="index.php">Home</a>/</li>
                            <li><a href="event.php"><?= $e['event_type_name'] ?? 'Events' ?></a>/</li>
                            <li><a href="services.php<?= (isset($_GET['event_id']) ? '?event_id='.$_GET['event_id'] : '' ) ?>">Services</a>/</li>
                            <li><a href="#"><?= $s['service_name']?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="container">
                    <div class="venues-view">
                        <div class="row">
                            <!--<div class="col-lg-3 col-md-3 col-sm-12">
                                <div class="left-side">
                                    <div class="search">
                                        <div class="search-icon"><div class="icon icon-search"></div></div>
                                        <input type="text" placeholder="Search by name">
                                    </div>
                                    <div class="filter-view">
                                        <div class="filter-block">
                                            <div class="title">
                                                <h2>Food And Drinks</h2>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-20"><input type="checkbox" name="sample-checkbox-01" id="checkbox-20" value="1">Non Vegetarian</label>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-21"><input type="checkbox" name="sample-checkbox-01" id="checkbox-21" value="1">Vegetarian</label>
                                            </div>
                                        </div>
                                        <div class="filter-block">
                                            <div class="title">
                                                <h2>Number of Guests</h2>
                                                <div class="reste-filter">
                                                    <a href="#"><span class="icon icon-reset"></span>Reset</a>
                                                </div>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-22"><input type="checkbox" name="sample-checkbox-01" id="checkbox-22" value="1">&lt; 10</label>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-23"><input type="checkbox" name="sample-checkbox-01" id="checkbox-23" value="1">10 - 100</label>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-24"><input type="checkbox" name="sample-checkbox-01" id="checkbox-24" value="1">100 - 200</label>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-25"><input type="checkbox" name="sample-checkbox-01" id="checkbox-25" value="1" checked="">200 - 500</label>
                                            </div>
                                            <div class="check-slide">
                                                <label class="label_check" for="checkbox-26"><input type="checkbox" name="sample-checkbox-01" id="checkbox-26" value="1" >&gt; 500</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="left-link">
                                        <h2>People also viewed...</h2>
                                        <ul>
                                            <li><a href="#"><span class="icon icon-arrow-right"></span>Denmark</a></li>
                                            <li><a href="#"><span class="icon icon-arrow-right"></span>Germany - Frankfurt / West</a></li>
                                            <li><a href="#"><span class="icon icon-arrow-right"></span>Greater Mexico City</a></li>
                                            <li><a href="#"><span class="icon icon-arrow-right"></span>HI - Big Island</a></li>
                                            <li><a href="#"><span class="icon icon-arrow-right"></span>Hungary</a></li>
                                            <li><a href="#"><span class="icon icon-arrow-right"></span>Poland</a></li>
                                        </ul>
                                    </div>
                                    <div class="left-productBox hidden-sm">
                                        <h2>Featured Venues</h2>
                                        <div class="product-img"><img src="assets/images/property-img/venues-img8.jpg" alt=""></div>
                                        <h3>Hilton Berlin </h3>
                                        <p>Mohrenstrasse 30 Berlin, 10117 - Germany</p>
                                        <div class="reviews">3.5 <div class="star"><div style="width:70%;" class="fill"></div></div>reviews</div>
                                        <a href="#">Vewi all Details <span class="icon icon-arrow-right"></span></a>
                                    </div>
                                </div>
                            </div>-->
                            <div class="col-md-10 col-lg-10 col-sm-12 col-lg-offset-1">
                                <div class="right-side">
                                    <div class="toolbar">
                                        <div class="finde-count"><?= count($serv)?> Vendor(s) found.  </div>
<!--                                        <div class="right-tool">-->
<!--                                            <div class="select-box">-->
<!--                                                <select name="country_id" id="setUp_select" tabindex="1" >-->
<!--                                                    <option>Near by</option>-->
<!--                                                    <option>Near by</option>-->
<!--                                                    <option>Near by</option>-->
<!--                                                    <option>Near by</option>-->
<!--                                                    <option>Near by</option>-->
<!--                                                </select>-->
<!--                                            </div>-->
<!--                                            <a href="#" class="shortlist-btn"><span class="icon icon-heart-filled"></span>7 Shortlist</a>-->
<!--                                            <div class="link">-->
<!--                                                <ul>-->
<!--                                                    <li><a href="#">Map</a></li>-->
<!--                                                    <li class="active"><a href="#">List</a></li>-->
<!--                                                </ul>-->
<!--                                            </div>-->
<!--                                        </div>-->

                                    </div>
                                    <?php
                                        foreach ($serv as $item)
                                        {

                                    ?>
                                    <div class="venues-slide">
                                        <div class="img"><img src="images/<?= $item['image']?>" alt=""></div>
                                        <div class="text">
                                            <h3><?= $item['vendor_service_name'] ?> </h3>
                                            <h4>Provider : <?= $item['org_name']?></h4>
                                            <div class="address">
                                                <?= $item['description']?>
                                            </div>
                                            <div><span class="icon icon-location-1" style="color: #f15b22"></span>
                                                <?= $loc->getLocation($item['city_id']) ?></div>
                                            <div class="outher-info">
                                                <div class="info-slide">
                                                    <label>Price</label>
                                                    <span>Rs. <?= $item['amount'] ?> </span>
                                                </div>
                                                <div class="info-slide">
                                                    <label>Vendor Rating</label>
                                                    <a href="javascript:void(0);" class="vendor_rate" data-toggle="modal" data-target="#vendor_rate" data-eid="<?= $item['vendor_id'] ?>">
                                                        <div class="star">
                                                            <div class="fill"
                                                                 style="width:calc(<?= $vendor->getVendorRate($item['vendor_id'], TRUE) ?> * 20%);"></div>
                                                        </div>
                                                    </a>

                                                </div>
                                                <div class="info-slide">
                                                    <label>Service Rating</label>
                                                    <a href="javascript:void(0);" class="vendor_service_rate" data-toggle="modal" data-target="#vendor_service_rate" data-eid="<?= $item['vendor_service_id'] ?>">
                                                        <div class="star">
                                                            <div class="fill" style="width:calc(<?= $service->getVendorServiceRate($item['vendor_service_id'], TRUE) ?> * 20%);"></div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="button">
                                                <a href="book_step1.php?<?= isset($_GET['event_id']) ? 'event_id='.$_GET['event_id'].'&' : '' ?>service_id=<?= $_GET['service_id'] ?>&vendor_service_id=<?= $item['vendor_service_id'] ?>" class="btn">Book Service</a>
                                                <button type="button" class="btn btn-danger" onclick="addToCart(<?= $item['vendor_service_id'] ?>)">Add to Cart</button>
                                                <a href="chat.php?vendor_id=<?= $item['vendor_id']?>" class="btn btn-success">Chat</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        }
                                    ?>
<!--                                    <div class="pagination">-->
<!--                                        <ul>-->
<!--                                            <li class="prev disabled"><a href="#">Prev</a></li>-->
<!--                                            <li class="active"><a href="#">1</a></li>-->
<!--                                            <li><a href="#">2</a></li>-->
<!--                                            <li><a href="#">3</a></li>-->
<!--                                            <li><a href="#">4</a></li>-->
<!--                                            <li><a href="#">5</a></li>-->
<!--                                            <li class="next"><a href="#">Next</a></li>-->
<!--                                        </ul>-->
<!--                                    </div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php
		include "footer.php";
        ?>
    </div>

    <div class="modal fade" id="vendor_rate" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">View Vendor Rate & Review</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Ratting</th>
                            <th>Review</th>
                        </tr>
                        </thead>
                        <tbody id="vendor_rate_body"></tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="vendor_service_rate" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">View Vendor Service Rate & Review</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Ratting</th>
                            <th>Review</th>
                        </tr>
                        </thead>
                        <tbody id="vendor_service_rate_body"></tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script type="text/javascript" src="assets/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.js"></script>
    <script type="text/javascript" src="assets/js/jquery.selectbox-0.2.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="assets/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="assets/js/placeholder.js"></script>
    <script type="text/javascript" src="assets/js/coustem.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>

    <script>
        async function addToCart(id) {
            const res = await fetch('model/book.php?ajax=true&addToCart=true&service_id=' + id);
            const obj = await res.json();
            if (obj >= 1){
                alert("Service is added to cart");
            } else{
                alert("Something is wrong.......");
            }
        }
        $(".vendor_rate").on('click', function (){
            let id = $(this).data('eid');

            $.ajax({
                url: 'model/vendor.php?ajax=true&vendor_all_rate_review=true&vendor_id=' + id,
                success:function (res) {
                    console.log(res);
                    if (res != ''){
                        let obj = JSON.parse(res);
                        let html = '';
                        for (const key in obj) {
                            html += '<tr>' +
                                '<td>' + obj[key].user_name + '</td>' +
                                '<td>';
                            for (let i = 1; i <= obj[key].rate; i++) {
                                html += '<i class="fas fa-star"></i>';
                            }
                            for (let i = obj[key].rate; i <5; i++) {
                                html += '<i class="far fa-star"></i>';
                            }
                            html += '</td>' +
                                '<td>' + obj[key].review + '</td>' +
                                '</tr>';
                        }
                        $("#vendor_rate_body").html(html);
                    }
                }
            })
        });

        $(".vendor_service_rate").on('click', function (){
            let id = $(this).data('eid');

            $.ajax({
                url: 'model/services.php?ajax=true&vendor_service_all_rate_review=true&vendor_service_id=' + id,
                success:function (res) {
                    console.log(res);
                    if (res != ''){
                        let obj = JSON.parse(res);
                        let html = '';
                        for (const key in obj) {
                            html += '<tr>' +
                                '<td>' + obj[key].user_name + '</td>' +
                                '<td>';
                            for (let i = 1; i <= obj[key].rate; i++) {
                                html += '<i class="fas fa-star"></i>';
                            }
                            for (let i = obj[key].rate; i <5; i++) {
                                html += '<i class="far fa-star"></i>';
                            }
                            html += '</td>' +
                                '<td>' + obj[key].review + '</td>' +
                                '</tr>';
                        }
                        $("#vendor_service_rate_body").html(html);
                    }
                }
            })
        });

    </script>

</body>
</html>

