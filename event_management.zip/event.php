<?php
require_once 'model/autoload.php';

$event = new Event();
$service = new Services();

$eventList = $event->getEnventType(($_GET['search'] ?? ''));
//echo "<pre>";
//print_r ($eventList);
//echo "</pre>";
//
//die();
$serv = $service->getServicesType();
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from design.dev.drcsystems.ooo:8084/themeforest/event_planning/search-result.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Sep 2020 19:19:20 GMT -->
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    
    <!-- Title -->
    <title>Event Planning</title>
    
    <!-- favicon icon -->
    <link rel="shortcut icon" href="assets/images/Favicon.ico">
    
    <!-- CSS Stylesheet -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="assets/css/styles.css" rel="stylesheet" /><!-- font css -->
    <link href="assets/css/jquery.selectbox.css" rel="stylesheet" /><!-- select Box css -->
    <link href="assets/css/datepicker.css" rel="stylesheet" /><!-- Date picker css -->
    <link href="assets/css/docs.css?version=1" rel="stylesheet"><!--  template structure css -->
    
    <!-- Used Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Domine:400,700%7COpen+Sans:300,300i,400,400i,600,600i,700,700i%7CRoboto:400,500" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
<body class="inner-page">
	<div class="page">

        <?php
            include 'header.php';
        ?>
        
        <div class="searchFilter-main">
            <section class="searchFormTop">
                <div class="container">
                    <div class="searchCenter">
                        <div class="refineCenter">
                            <span class="icon icon-filter"></span>
                            <span>Refine Results</span> 
                        </div>
                        <div class="searchFilter">
                            <form method="get">
                                <div class="input-box">
                                    <div class="icon icon-grid-view"></div>
                                    <input type="text" name="search" placeholder="Search Events" value="<?= ($_GET['search'] ?? '' )?>">
                                </div>
                                <!--                            <div class="input-box searchlocation">-->
                                <!--                                <div class="icon icon-location-1"></div>-->
                                <!--                                <input type="text" placeholder="Germany - Berlin / East">-->
                                <!--                            </div>-->
                                <input type="submit" class="btn">
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <section class="content">
                <div class="breadcrumb">
                    <div class="container">
                        <ul>
                            <li><a href="#">Home</a>/</li>
                            <li><a href="#">Events</a></li>
                        </ul>
                    </div>
                </div>
                <div class="container">
                    <div class="venues-view">
                        <div class="row">
                            <div class="col-md-10 col-lg-10 col-sm-12 col-lg-offset-1">
                                <div class="right-side">
                                    <div class="toolbar">
                                        <div class="finde-count"><?= count($eventList)?> Events found.  </div>

                                    </div>
                                    <?php
                                        foreach ($eventList as $item)
                                        {

                                    ?>
                                    <div class="venues-slide">
                                        <div class="img"><img src="images/<?= $item->image?>" alt=""></div>
                                        <div class="text">
                                            <h3><?= $item->event_type_name ?> </h3>
                                            <h4>Services</h4>
                                            <div class="address">
                                                <?php
                                                $i=0;
												foreach($serv as $s)
												{
												    if ($i++ == 4){
												        break;
													}
													echo $s->service_name . "<br>";
												}
                                                ?>
                                            </div>

                                            <div class="button">
                                                <a href="services.php?event_id=<?= $item->event_type_id?>" class="btn">Book Now</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php
        include 'footer.php';
        ?>
    </div>
	


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <script type="text/javascript" src="assets/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.js"></script>
    <script type="text/javascript" src="assets/js/jquery.selectbox-0.2.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="assets/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="assets/js/placeholder.js"></script>
    <script type="text/javascript" src="assets/js/coustem.js"></script>
    <script type="text/javascript" src="assets/js/login.js"></script>
    
</body>

<!-- Mirrored from design.dev.drcsystems.ooo:8084/themeforest/event_planning/search-result.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Sep 2020 19:19:42 GMT -->
</html>

