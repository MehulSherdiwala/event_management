<?php
	require_once "../model/autoload.php";
//	echo base_url;
if (!isset($_SESSION['admin_id'])){
	header('location:' . base_url . 'admin/login.php');
}
$admin = new Admin();

$data = $admin->getCount();

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<meta name="description" content="Responsive Admin Template" />
	<meta name="author" content="SmartUniversity" />
	<title>Event Planning</title>
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
	<!-- icons -->
	<link href="<?= base_url ?>assets/fonts/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/fonts/material-design-icons/material-icon.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/fonts/fontawesome/css/all.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<!--bootstrap -->
	<link href="<?= base_url ?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/plugins/summernote/summernote.css" rel="stylesheet">
	<!-- Material Design Lite CSS -->
	<link rel="stylesheet" href="<?= base_url ?>assets/plugins/material/material.min.css">
	<link rel="stylesheet" href="<?= base_url ?>assets/css/material_style.css">
	<!-- inbox style -->
	<link href="<?= base_url ?>assets/css/pages/inbox.min.css" rel="stylesheet" type="text/css" />
	<!-- Theme Styles -->
	<link href="<?= base_url ?>assets/css/theme/light/theme_style.css?version=2" rel="stylesheet" id="rt_style_components" type="text/css" />
	<link href="<?= base_url ?>assets/css/plugins.min.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/css/theme/light/style.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="<?= base_url ?>assets/css/theme/light/theme-color.css" rel="stylesheet" type="text/css" />
	<!-- favicon -->
	<link rel="shortcut icon" href="../assets/images/Favicon.ico" />
</head>
<!-- END HEAD -->

<body
	class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
	<!-- start header -->
    <?php
        include "header.php";
    ?>
	<!-- end color quick setting -->
	<!-- start page container -->
	<div class="page-container">
        <?php
            include "sidebar.php";
        ?>
		<!-- start page content -->
		<div class="page-content-wrapper">
			<div class="page-content">
				<div class="page-bar">
					<div class="page-title-breadcrumb">
						<div class=" pull-left">
							<div class="page-title">Dashboard</div>
						</div>
						<ol class="breadcrumb page-breadcrumb pull-right">
							<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
																   href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
							</li>
							<li class="active">Dashboard</li>
						</ol>
					</div>
				</div>
				<!-- start widget -->
				<div class="state-overview">
					<div class="row">
						<div class="col-xl-3 col-md-6 col-12">
							<div class="info-box bg-b-green">
								<span class="info-box-icon"><i class="material-icons">group</i></span>
								<div class="info-box-content">
									<span class="info-box-text">Total Vendors</span>
									<span class="info-box-number"><?= $data['vendors'] ?></span>
								</div>
								<!-- /.info-box-content -->
							</div>
							<!-- /.info-box -->
						</div>
						<!-- /.col -->
						<div class="col-xl-3 col-md-6 col-12">
							<div class="info-box bg-b-yellow">
								<span class="info-box-icon"><i class="material-icons">person</i></span>
								<div class="info-box-content">
									<span class="info-box-text">New Users</span>
									<span class="info-box-number"><?= $data['users'] ?></span>
								</div>
								<!-- /.info-box-content -->
							</div>
							<!-- /.info-box -->
						</div>
						<!-- /.col -->
						<div class="col-xl-3 col-md-6 col-12">
							<div class="info-box bg-b-blue">
								<span class="info-box-icon"><i class="material-icons">event</i></span>
								<div class="info-box-content">
									<span class="info-box-text">Total Events</span>
									<span class="info-box-number"><?= $data['events'] ?></span>
								</div>
								<!-- /.info-box-content -->
							</div>
							<!-- /.info-box -->
						</div>
						<!-- /.col -->
						<div class="col-xl-3 col-md-6 col-12">
							<div class="info-box bg-b-pink">
									<span class="info-box-icon"><i
											class="material-icons">event_available</i></span>
								<div class="info-box-content">
									<span class="info-box-text">Total Services</span>
									<span class="info-box-number"><?= $data['services'] ?></span>
								</div>
								<!-- /.info-box-content -->
							</div>
							<!-- /.info-box -->
						</div>
						<!-- /.col -->
					</div>
				</div>
				<!-- end widget -->
				<!-- chart start -->
				<div class="row">
					<div class="col-sm-12">
						<div class="card card-box">
							<div class="card-head">
								<header>User Joined</header>
								<div class="tools">
									<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
									<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
									<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
								</div>
							</div>
							<div class="card-body">
								<div class="recent-report__chart">
									<div id="chart1"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- end new student list -->
			</div>
		</div>
		<!-- end chat sidebar -->
	</div>
	<!-- end page container -->
	<!-- start footer -->
	<div class="page-footer">
		<div class="page-footer-inner"> 2020 &copy; Event Planning</div>
		<div class="scroll-to-top">
			<i class="icon-arrow-up"></i>
		</div>
	</div>
	<!-- end footer -->
</div>
<!-- start js include path -->
<script src="<?= base_url ?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url ?>assets/plugins/popper/popper.js"></script>
<script src="<?= base_url ?>assets/plugins/jquery-blockui/jquery.blockui.min.js"></script>
<script src="<?= base_url ?>assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- bootstrap -->
<script src="<?= base_url ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url ?>assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="<?= base_url ?>assets/plugins/sparkline/jquery.sparkline.js"></script>
<script src="<?= base_url ?>assets/js/pages/sparkline/sparkline-data.js"></script>
<!-- Common js-->
<script src="<?= base_url ?>assets/js/app.js"></script>
<script src="<?= base_url ?>assets/js/layout.js"></script>
<script src="<?= base_url ?>assets/js/theme-color.js"></script>
<!-- material -->
<script src="<?= base_url ?>assets/plugins/material/material.min.js"></script>
<!--apex chart-->
<script src="<?= base_url ?>assets/plugins/apexcharts/apexcharts.min.js"></script>
<script src="<?= base_url ?>assets/js/pages/chart/chartjs/home-data.js?version=2"></script>
<!-- end js include path -->
</body>
</html>
